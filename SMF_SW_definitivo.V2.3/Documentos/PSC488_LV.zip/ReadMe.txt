--------------------------------------------------------------------------------------------------------------------------------------------------------------
Delta Elektronika 
Visserdijk 4
4301 ND  Zierikzee
The Netherlands
Tel: +31 111 413656
Fax: +31 111 416919
E-Mail: support@deltapowersupplies.com
Website: http://www.deltapowersupplies.com
--------------------------------------------------------------------------------------------------------------------------------------------------------------
All this Software is provided �as is� and is without any warranty, the use of this Software is entirely at your own risk.
All trademarks and registered trademarks are the property of their respective owners.
--------------------------------------------------------------------------------------------------------------------------------------------------------------


PSC-232/488 Driver CD-ROM V4.2, August 2011


Programming language
--------------------------------------------------------------------------------------------------------------------------------------------------------------
PSC488 LabVIEW library�s for Microsoft Windows(TM) based systems
  - PSC488_V71.llb for LabVIEW 7.1
--------------------------------------------------------------------------------------------------------------------------------------------------------------

Contents
--------------------------------------------------------------------------------------------------------------------------------------------------------------
PSC488_V71.llb contains the following main VI's. 
These VI�s use the other not mentioned, but included sub. VI's.

Main VI Name            		Description
PSC488 Application.vi   		Demo example program to control a PSC488
PSC488 Terminal.vi 		Try out GPIB terminal program
PSC488 Driver.vi			Virtual Instrument
PSC488 Calibration.vi		Calibration VI to calibrate a PSC488 with a power supply
PSC488 Modif_Password.vi  		Change password
CalibratePSC488Visa61.LLB     	Calibration VI with the use of VISA
--------------------------------------------------------------------------------------------------------------------------------------------------------------

Revision(s)
----------------------------------------------------------------------------------------------------------------------------------------------------------
PSC488_V7*.LLB Rev. 30/08/2011
 - Fixed decimal seperator (dot/comma). The dot is now automaticaly used as decimal seperator
 - Saved the old version librarys (LabVIEW V6.0 and V6.1) to LabVIEW 7.1

PSC488_V6*.LLB Rev. 17/02/2009
 - Fixed a bug which made it difficult to change the used GPIB channel
 - Fixed and added some PSC-488 option numbers

PSC488_V6*.LLB Rev. 04/09/2008
  - Updated the command SO:V0 to SO:VO in the "Voltage programming 
    offset calibration" part of the calibration vi
----------------------------------------------------------------------------------------------------------------------------------------------------------
